DROP PROCEDURE create_departments_noex;
DROP PROCEDURE query_emp;
DROP PROCEDURE format_phone;
DROP PROCEDURE add_dept;
DROP PROCEDURE process_employees;
DROP PROCEDURE create_departments;
DROP PROCEDURE add_department_noex;
DROP PROCEDURE p;
