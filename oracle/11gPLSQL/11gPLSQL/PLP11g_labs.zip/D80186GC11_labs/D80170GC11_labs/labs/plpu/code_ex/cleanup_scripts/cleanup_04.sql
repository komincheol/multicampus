
drop PACKAGE comm_pkg;
drop PACKAGE global_consts;
drop FUNCTION mtr2yrd;