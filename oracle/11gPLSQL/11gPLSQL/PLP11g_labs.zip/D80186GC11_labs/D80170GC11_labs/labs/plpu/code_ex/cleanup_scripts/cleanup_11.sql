DROP PROCEDURE add_job_history;
DROP PROCEDURE compile_code;
DROP PROCEDURE p;

DROP TABLE t;

DROP package my_pkg;