--The SQL Script to run the solution for Practice 2

--Uncomment code below to run the solution for Task 2 of Practice 2

/*
SET SERVEROUTPUT ON

BEGIN
DBMS_OUTPUT.PUT_LINE(' Hello World ');
END;
*/

