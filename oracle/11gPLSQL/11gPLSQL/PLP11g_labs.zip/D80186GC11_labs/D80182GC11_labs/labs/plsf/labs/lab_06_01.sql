DROP TABLE messages;
CREATE TABLE messages (results VARCHAR2(80));
