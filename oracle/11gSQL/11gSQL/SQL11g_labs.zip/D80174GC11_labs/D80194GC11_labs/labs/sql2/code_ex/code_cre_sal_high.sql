DROP TABLE sal_high;
CREATE TABLE sal_high 
( employee_id number(6,0),
  last_name varchar2(25),
  salary number(8,2)
);