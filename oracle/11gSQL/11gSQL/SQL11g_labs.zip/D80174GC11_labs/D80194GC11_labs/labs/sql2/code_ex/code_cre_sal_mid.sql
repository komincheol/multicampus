DROP TABLE sal_mid;
CREATE TABLE sal_mid 
( employee_id number(6,0),
  last_name varchar2(25),
  salary number(8,2)
);