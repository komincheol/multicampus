DROP TABLE deptm3;

DROP TABLE sales_reps;

DROP TABLE mgr_history;

DROP TABLE sal_history;

DROP TABLE emp_history;

DROP TABLE emp_sales;

DROP TABLE managers2;

DROP TABLE sal_low;

DROP TABLE sal_high;

DROP TABLE sal_mid;

DROP TABLE SALES_INFO;

DROP TABLE SALES_SOURCE_DATA;

DROP TABLE COPY_EMP3;

DROP TABLE emp3;

DROP TABLE employees3;
