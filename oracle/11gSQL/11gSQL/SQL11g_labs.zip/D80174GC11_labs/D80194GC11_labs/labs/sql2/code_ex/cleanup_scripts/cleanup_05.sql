DROP TABLE cart;

DROP TABLE emp_details;

DROP TABLE emp_ext;

DROP TABLE oldemp;