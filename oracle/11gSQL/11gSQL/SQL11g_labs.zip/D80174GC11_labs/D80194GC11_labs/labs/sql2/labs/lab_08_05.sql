insert into contacts
values ('a', '(111) 555-5555');

insert into contacts
values ('b', '(222) 555-3427');

insert into contacts
values ('c', '333 555 3427');

insert into contacts
values ('d', '444 555 3427');

insert into contacts
values ('e', '555-555-3427');

insert into contacts
values ('f', '(666) 555-3427');

insert into contacts
values ('g', ' (777) 555-3427')