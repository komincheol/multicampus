-- If you get any warning message, please ignore it

DROP TABLE emp3;
CREATE TABLE emp3 AS
SELECT * FROM employees;
