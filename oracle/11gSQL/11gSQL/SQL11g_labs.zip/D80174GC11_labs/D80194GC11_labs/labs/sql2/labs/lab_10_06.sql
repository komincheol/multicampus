DROP TABLE sample_dates;

CREATE TABLE sample_dates (date_col date);

Insert into sample_dates values (sysdate);