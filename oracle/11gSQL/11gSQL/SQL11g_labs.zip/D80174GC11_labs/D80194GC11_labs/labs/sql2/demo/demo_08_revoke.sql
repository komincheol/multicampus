--Execute the following with the demo user

SELECT * FROM teach_b.departments;



