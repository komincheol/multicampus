
DROP TABLE emp4;

DROP TABLE web_orders;

DROP TABLE warranty;

DROP TABLE lab;

