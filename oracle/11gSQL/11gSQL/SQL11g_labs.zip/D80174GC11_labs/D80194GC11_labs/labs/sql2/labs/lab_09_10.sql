DROP TABLE emp_hist;
CREATE TABLE emp_hist AS
SELECT first_name, last_name,email FROM employees;