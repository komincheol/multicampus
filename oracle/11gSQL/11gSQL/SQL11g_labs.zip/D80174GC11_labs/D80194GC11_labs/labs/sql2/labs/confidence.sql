SELECT count(*) FROM tab;
SELECT count(*) FROM employees;
SELECT count(*) FROM countries;
SELECT count(*) FROM regions;
SELECT count(*) FROM locations;
SELECT count(*)  FROM departments;
SELECT count(*) FROM jobs;
SELECT count(*) FROM job_history;

