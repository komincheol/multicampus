DROP TABLE loc;

DROP TABLE empl6;

DROP TABLE rewards;

DROP TABLE emp_history;