DROP SEQUENCE dept_deptid_seq;

DELETE FROM departments
WHERE department_name='Support';

DROP TABLE emp;

DROP TABLE NEW_EMP cascade constraints;

DROP TABLE EMP_UNNAMED_INDEX;

DROP TABLE NEW_EMP2;

DROP TABLE dept2 CASCADE CONSTRAINTS;

DROP TABLE emp2;

DROP TABLE emp_lib;

DROP TABLE emp_test;

DROP TABLE MYEMP1;









