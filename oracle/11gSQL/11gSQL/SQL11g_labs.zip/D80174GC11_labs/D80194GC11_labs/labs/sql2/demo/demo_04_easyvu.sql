CREATE OR REPLACE VIEW simple_vu
AS SELECT employee_id, last_name, salary
FROM   employees
/
