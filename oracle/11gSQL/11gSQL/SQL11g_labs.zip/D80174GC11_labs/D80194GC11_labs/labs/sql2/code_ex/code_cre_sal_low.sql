DROP TABLE sal_low;
CREATE TABLE sal_low 
( employee_id number(6,0),
  last_name varchar2(25),
  salary number(8,2)
);