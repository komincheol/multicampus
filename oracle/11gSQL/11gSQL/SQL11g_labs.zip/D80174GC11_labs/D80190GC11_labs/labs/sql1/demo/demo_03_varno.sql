SELECT  job_id, last_name
FROM	employees
ORDER BY job_id, last_name
