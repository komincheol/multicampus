DROP TABLE hire_dates;

DROP TABLE  dept;

DROP TABLE teach_emp;