SELECT	department_id, COUNT(last_name)
FROM	employees
/
