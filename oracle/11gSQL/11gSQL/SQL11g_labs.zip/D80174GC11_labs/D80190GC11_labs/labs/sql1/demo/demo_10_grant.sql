-- Please add a valid user id in the grant statement below.

GRANT SELECT,UPDATE 
ON departments 
TO &db_user
/
