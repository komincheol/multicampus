SELECT 
NLS_INITCAP('ábrahám', 'NLS_SORT = Xhungarian') "Initcap",
NLS_UPPER('ábrahám', 'NLS_SORT = Xhungarian') "upper",
NLS_LOWER('ÉZSAIÁS', 'NLS_SORT = Xhungarian') "lower" 
from dual;
