--Execute by using teach_a account
create table mytab (col1 varchar2(10));
alter table mytab add (col2 number invisible);
describe mytab ;
