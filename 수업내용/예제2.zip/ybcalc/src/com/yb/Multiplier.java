package com.yb;

public class Multiplier extends Calculator {

	@Override
	float calculate(float a, float b) {
		// TODO Auto-generated method stub
		return a * b;
	}

}
