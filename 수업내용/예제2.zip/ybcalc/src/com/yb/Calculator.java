package com.yb;

public abstract class Calculator {
	abstract float calculate (float a, float b);
}
