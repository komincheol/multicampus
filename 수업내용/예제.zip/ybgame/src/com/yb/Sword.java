package com.yb;

public class Sword extends Weapon {
	public void useWeapon () {
		System.out.println("Į�� �ֵθ��ϴ�!");
	}
}
